﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApp
{

    public class BankAccount
    {

        protected double interestRate;
        protected string owner;
        protected double balance;
        protected string accountype;


        public BankAccount()
        {
        }

        public BankAccount(string owner, double balance, double interestRate, string accountype)
        {
            this.interestRate = interestRate;
            this.owner = owner;
            this.balance = balance;
            this.accountype = accountype;
        }

      

       // public BankAccount(string o, double ir) :
        //  this(o, 0.0M, ir)
        //{
        //}

        public virtual double Balance
        {
            get { return balance; }
            set { balance = value; }
        }

        public virtual void Withdraw(double amount)
        {
            balance -= amount;
        }

        public virtual void Deposit(double amount)
        {
            balance += amount;
        }

        public virtual void AddInterests()
        {
            balance += balance * (double)interestRate;
        }

        public override string ToString()
        {
            return owner + "'s account holds " +
                  +balance + " kroner";
        }
    }

    public class CheckAccount : BankAccount
    {

        public CheckAccount(string owner,double balance, double interestrate) :
          base(owner, balance, interestrate,"Checking")
        {
        }

        

        public override void Withdraw(double amount)
        {
            balance -= amount;
            if (amount < balance)
                interestRate = -0.10;
        }

        public override string ToString()
        {
            return owner + "'s check account holds " +
                  +balance + " kroner";
        }
    }

    public class SavingsAccount : BankAccount
    {

        public SavingsAccount(string owner, double balance, double interestrate) :
          base(owner, balance, interestrate, "Saving")
        {
        }

       

        public override void Withdraw(double amount)
        {
            if (amount < balance)
                balance -= amount;
            else
                throw new Exception("Cannot withdraw");
        }

        public override void AddInterests()
        {
            balance = balance + balance * (double)0.5;
        }

        public override string ToString()
        {
            return owner + "'s savings account holds " +
                  +balance + " kroner";
        }


        class Program
        {
            static void Main(string[] args)
            {

                Console.Write("press 1 for opening the account");
                string keypress = Console.ReadLine().ToString();
                if (keypress == "1")
                {

                    SavingsAccount objSavingAccount;
                    CheckAccount objCheckAccount;
                     Console.WriteLine("Please Enter what type Of account 1 for Checkin 2 for Saving");
                    string accountype = Console.ReadLine().ToString();

                    Console.WriteLine("Enter the name of the person");
                    string name = Console.ReadLine().ToString();

                    Console.WriteLine("Enter the balance of the person");
                    double balance = Convert.ToDouble(Console.ReadLine().ToString());


                   

                    Console.WriteLine("Enter transaction you want 1 Deposit 2 withdrawl 3 Transfer");
                    string transactionType = Console.ReadLine();
                    if (transactionType == "1")
                    {

                        Console.WriteLine("Enter the Amount you want to Deposit");
                        string amount = Console.ReadLine();
                        if (accountype == "1")
                        {
                            

                                objCheckAccount = new CheckAccount(name, balance, 0.0);

                                objCheckAccount.Deposit(Convert.ToDouble(amount));
                                Console.WriteLine("Your Total Balance is" + objCheckAccount.ToString());
                               Console.ReadKey();
                        }

                        if (accountype == "2")
                        {

                                objSavingAccount = new SavingsAccount(name, balance, 0.5);
                               objSavingAccount.Deposit(Convert.ToDouble(amount));
                                Console.WriteLine("Your Total Balance is"+ objSavingAccount.ToString());
                            Console.ReadKey();
                        }



                    }

                    //withdrawl
                    if (transactionType == "2")
                    {

                        Console.WriteLine("Enter the Amount you want to withdraw");
                        string amount = Console.ReadLine();
                        if (accountype == "1")
                        {


                            objCheckAccount = new CheckAccount(name, balance, 0.0);
                            if (balance < Convert.ToDouble(amount) || Convert.ToDouble(amount) > 1000)
                            {
                                Console.WriteLine("you are not allowed to withdraw more then your balance and not more than 1000");
                                Console.ReadKey();
                            }
                            else
                            {
                                objCheckAccount.Withdraw(Convert.ToDouble(amount));
                                Console.WriteLine("Your Total Balance is" + objCheckAccount.ToString());
                                Console.ReadKey();
                            }

                        }

                        if (accountype == "2")
                        {

                            objSavingAccount = new SavingsAccount(name, balance, 0.5);
                            if (balance < Convert.ToDouble(amount) || Convert.ToDouble(amount)>1000)
                            {
                                Console.WriteLine("you are not allowed to withdraw more then your balance and not more then 1000");
                                Console.ReadKey();

                            }
                            else
                            {
                                objSavingAccount.Withdraw(Convert.ToDouble(amount));
                                Console.WriteLine("Your Total Balance is" + objSavingAccount.ToString());
                                Console.ReadKey();
                            }

                        }



                    }




                    //transfer
                    if (transactionType == "3")
                    {

                        Console.WriteLine("Enter the Amount you want to transfer");
                        string amount = Console.ReadLine();
                        if (accountype == "1")
                        {


                            objCheckAccount = new CheckAccount(name, balance, 0.0);
                            if (balance < Convert.ToDouble(amount) )
                            {
                                Console.WriteLine("you are not allowed to transfer  more then your balance");
                            }
                            else
                            {
                                objCheckAccount.Withdraw(Convert.ToDouble(amount));
                                Console.WriteLine("Your Total Balance is" + objCheckAccount.ToString());

                            }

                        }

                        if (accountype == "2")
                        {

                            objSavingAccount = new SavingsAccount(name, balance, 0.5);
                            if (balance < Convert.ToDouble(amount) || Convert.ToDouble(amount) > 1000)
                            {
                                Console.WriteLine("you are not allowed to transfer  more then your balance");
                            }
                            else
                            {
                                objSavingAccount.Withdraw(Convert.ToDouble(amount));
                                Console.WriteLine("Your Total Balance is" + objSavingAccount.ToString());

                            }

                        }



                    }









                }
            }
        }
    }
}