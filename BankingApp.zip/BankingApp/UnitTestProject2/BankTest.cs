﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BankingApp;

namespace UnitTestProject2
{
    [TestClass]
    public class BankTest
    {
        [TestMethod]
        public void CheckDeposit()
        {

            //Arrange
            int expected = 2000;
            int balance = 1000;
            int deposit = 1000;
            //Act
            BankAccount obj = new BankAccount();
            obj.Balance = balance;
            obj.Deposit(deposit);
            //Assert
            Assert.AreEqual(obj.Balance, expected);

        }


        [TestMethod]
        public void CheckWithdrawl()
        {

            //Arrange
            int expected = 1000;
            int balance = 2000;
            int withdrawl = 1000;
            //Act
            BankAccount obj = new BankAccount();
            obj.Balance = balance;
            obj.Withdraw(withdrawl);
            //Assert
            Assert.AreEqual(obj.Balance, expected);

        }


    }
}
